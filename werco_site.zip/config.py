SQLALCHEMY_DATABASE_URI = "sqlite:///database.db"
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "1234"
SECRET_KEY = "DFGHJasefghjml;p98hnbvftfddvhjk,lhdrwsd"